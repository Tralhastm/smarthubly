#!/bin/bash
# Instalação automática do bot WhatsApp — NÃO precisa de permissão de storage.
# Tudo roda dentro da pasta interna do Termux ($HOME).
set -e

echo ""
echo "=== Bot WhatsApp Aços — instalação automática ==="

# 1. Atualiza pacotes
pkg update -y >/dev/null 2>&1 || true
pkg upgrade -y >/dev/null 2>&1 || true

# 2. Instala Node.js e ferramentas de download
pkg install -y nodejs curl unzip git

# 3. Baixa o bot direto da internet (sem precisar de storage!)
cd ~
rm -rf bot-termux
mkdir -p bot-termux
cd bot-termux
curl -sL "https://9090-ijpev69vu230clq9t5zsm-7c5203de.us4.manus.computer/bot-termux.zip" -o pacote.zip
unzip -o pacote.zip -d . >/dev/null
rm -f pacote.zip

# 4. Instala as bibliotecas do bot
npm install --no-fund --no-audit baileys@6 qrcode-terminal libphonenumber-js https-proxy-agent

# 5. Permite rodar os scripts
chmod +x start.sh

echo ""
echo "=== INSTALAÇÃO CONCLUÍDA! ==="
echo ""
echo "Próximo passo: rode  ./start.sh"
echo ""
echo "O QR CODE vai aparecer na tela."
echo "Abra o WhatsApp do número do bot (11 91287-0761),"
echo "toque nos 3 pontinhos > Dispositivos conectados > Conectar dispositivo,"
echo "e aponte a câmera para o QR code na tela do celular."
