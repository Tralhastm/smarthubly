/**
 * Bot WhatsApp — Serralheria Smart Aços (aço galvanizado e inox)
 * Versão Termux (Android) — v5 CONVERSA FLUIDA 🗣️
 *
 * Sem menu numerado. O bot entende linguagem natural:
 *  - "oi, boa tarde!"            → responde como um atendente
 *  - "quero um portão de 3m"     → entende serviço + medida, já calcula
 *  - "portão de 3m em inox"      → entende serviço + medida + material, fecha orçamento
 *  - "tem garantia?" / "atende onde?" → responde como humano
 *
 * Fluxo: saudação → orçamento natural → visita técnica → encaminhamento humano
 */

const fs = require("fs");
const path = require("path");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
} = require("baileys");
const QRCode = require("qrcode-terminal");

const CFG = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8"));
/* ---------- proxy para redes corporativas / bloqueadas ---------- */
let proxyAgent = null;
if (CFG.proxy) {
  try {
    const { HttpsProxyAgent } = require("https-proxy-agent");
    proxyAgent = new HttpsProxyAgent(CFG.proxy);
    console.log("🔗 Bot usando proxy:", CFG.proxy);
  } catch (e) {
    console.log("⚠️ falha ao carregar proxy:", e.message);
  }
}

const AUTH_DIR = path.join(__dirname, "auth");
const HUMANO_NUM = process.env.HUMANO_NUM || "5511912870761@s.whatsapp.net";
const PREÇOS = CFG.servicos;
const EMPRESA = CFG.nome_empresa || "Serralheria Smart Aços";

/* ============== IA — Workers (SmartHubly) com fallback Gemini ============== */
// O catálogo local tenta primeiro (instantâneo). A IA só responde quando o
// bot não detecta serviço. Workers = manutenção centralizada (prompt/chaves
// no SmartHubly); se o worker cair, o Gemini direto garante o entendimento.
const IA_CFG = (CFG.ia && CFG.ia.habilitada) ? CFG.ia : null;

/* Mapeia a intenção do Worker (IA) para o vocabulário interno do bot */
const MAPA_INTENCAO_IA = {
  orcamento: "orcamento",
  pergunta_info: "pergunta_info",
  agendar_visita: "humano",
  chamar_humano: "humano",
  saudacao: "saudacao",
  despedida: "despedida",
  resposta_sim: "sim",
  resposta_nao: "nao",
  negociacao: "ta_caro",
  desconhecido: null,
};

function normalizarNomeIA(servicoIA) {
  // casa o serviço retornado pela IA com uma chave exata do catálogo (case-insensitive, acentos)
  if (!servicoIA) return null;
  const alvo = normalizar(servicoIA);
  for (const chave of Object.keys(PREÇOS)) {
    if (normalizar(chave) === alvo) return chave;
  }
  // fallback: casa com os apelidos
  for (const [chave, apelidos] of Object.entries(APELIDOS_SERVICO)) {
    for (const ap of apelidos) {
      if (normalizar(ap) === alvo || alvo.includes(normalizar(ap)) && normalizar(ap).length > 3) return chave;
    }
  }
  return null;
}

function parseWorkerOut(out) {
  if (!out || typeof out !== "object") return null;
  // "erro" = "mensagem vazia" é resposta válida de IA (intenção irrelevante) — só ignorar erros reais
  if (out.erro && out.erro !== "mensagem vazia") return null;
  const intencaoIA = out.intencao ? String(out.intencao) : null;
  return {
    servico: normalizarNomeIA(out.servico),
    medida: (out.medida === null || out.medida === "null" || out.medida === "indefinida") ? null : out.medida,
    material: /inox/i.test(out.material || "") ? "inox" : /galvaniz/i.test(out.material || "") ? "galvanizado" : null,
    intencao: MAPA_INTENCAO_IA[intencaoIA] !== undefined ? MAPA_INTENCAO_IA[intencaoIA] : null,
    resumo: out.extra || null,
    resposta_natural: out.resposta_natural || null,
    encaminhar_humano: !!out.encaminhar_humano,
    confiavel: !!out.confiavel,
    fonte: "ia",
  };
}

// Sync por mensagem: o perfil da loja é recarregado a cada mensagem (cache curto de 30s)
// — assim qualquer mudança no Super Admin aparece na próxima resposta, sem polling pesado.
const SUPABASE_FIXO = "https://qbcplbcdxoyqpmcehnvu.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFiY3BsYmNkeG95cXBtY2VobnZ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY2NTk1NjAsImV4cCI6MjEwMjIzNTU2MH0.Qmg4xBNcLhnPYBlB7EWZyRRLHZqSqnAJZCjkHk1Kl78";
function botTelefoneAtual() {
  return (CFG.bot_telefone || (sock && (String(sock.user && sock.user.id || "").match(/(\d{8,15})/) || [])[1]) || "").toString();
}

// Perfil da loja recarregado a cada mensagem (o cache curto só evita spam em sequência)
let _cacheBot = null, _cacheBotExpira = 0;
const _CACHE_SEG = 30 * 1000;
function botDaLoja(telefone, opts) {
  // opts.refresh=true força o reload (usado a cada mensagem — assim o bot reflete
  // o Super Admin em até 30s, sem ficar 5 min com dados velhos)
  const agora = Date.now();
  const refresh = opts && opts.refresh;
  const silencioso = opts && opts.silencioso;
  if (!refresh && _cacheBot && _cacheBotExpira > agora) return Promise.resolve(_cacheBot);
  const REST = (CFG.ia && CFG.ia.supabase_url) || (IA_CFG && IA_CFG.worker_url ? IA_CFG.worker_url.replace("/functions/v1/serralheria-intent", "") : null) || SUPABASE_FIXO;
  if (!REST) { console.log("[botDaLoja] sem URL do Supabase (ia config ausente)"); return Promise.resolve(null); }
  return fetch(REST + "/rest/v1/whatsapp_bots?telefone=eq." + telefone + "&select=id,loja_nome,segmento,mensagem_boas_vindas&limit=1", {
    agent: proxyAgent, headers: { "apikey": ANON_KEY, "Authorization": "Bearer " + ANON_KEY },
  })
    .then(r => {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    })
    .catch((e) => {
      // 1ª tentativa com proxy falhou? tenta SEM proxy (rede local do Termux)
      console.log("[botDaLoja] 1ª tentativa falhou (" + (e && e.message) + ") — tentando sem proxy...");
      return fetch(REST + "/rest/v1/whatsapp_bots?telefone=eq." + telefone + "&select=id,loja_nome,segmento,mensagem_boas_vindas&limit=1", {
        headers: { "apikey": ANON_KEY, "Authorization": "Bearer " + ANON_KEY },
      }).then(r => r.ok ? r.json() : null);
    })
    .then(rows => {
      const bot = (rows && rows[0]) || null;
      if (bot) { _cacheBot = bot; _cacheBotExpira = Date.now() + _CACHE_SEG; }
      if (!silencioso) console.log("[botDaLoja]", bot ? "ok: " + bot.loja_nome : "sem registro (tel " + telefone + ")");
      return bot;
    })
    .catch(() => null);
}
function IA_URL_BASE() {
  // deriva a URL base do Supabase a partir do worker_url
  return IA_CFG && IA_CFG.worker_url ? IA_CFG.worker_url.replace("/functions/v1/serralheria-intent", "") : null;
}
const SR_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFiY3BsYmNkeG95cXBtY2VobnZ1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4NjY1OTU2MCwiZXhwIjoyMTAyMjM1NTYwfQ.-240BmCDt6tBty57T3qqX1yhi4S2w_m9P4nQxS2RAZI";

function pedirIA(jid, texto) {
  if (!IA_CFG) return Promise.resolve(null);
  // 1) SmartHubly — Supabase Edge Function (motor multi-tenant: resolve o bot da loja pelo número do cliente)
  if (IA_CFG.worker_url) {
    return fetch(IA_CFG.worker_url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      agent: proxyAgent,
      body: JSON.stringify({ mensagem: texto, telefone: jid.replace(/@.*/, ""), telefone_do_bot: CFG.bot_telefone || "" }),
    })
      .then(r => { if (!r.ok) throw new Error("Supabase HTTP " + r.status); return r.json(); })
      .then(parseWorkerOut)
      .then(p => { if (p) return p; throw new Error("Supabase vazio"); })
      // 2) fallback: worker Cloudflare legado (se worker_url_backup estiver no config)
      .catch(e => {
        console.log("⚠️", e.message, "→ tentando worker de backup (Cloudflare)");
        if (!IA_CFG.worker_url_backup) throw e;
        return fetch(IA_CFG.worker_url_backup + "/entender", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          agent: proxyAgent,
          body: JSON.stringify({ mensagem: texto, telefone: jid.replace(/@.*/, ""), telefone_do_bot: CFG.bot_telefone || "" }),
        })
          .then(r => { if (!r.ok) throw new Error("backup HTTP " + r.status); return r.json(); })
          .then(parseWorkerOut)
          .then(p => { if (p) return p; throw new Error("backup vazio"); });
      })
      // 3) último recurso: Gemini direto (grátis, rota com 6 chaves)
      .catch(e => { console.log("⚠️ IA externa indisponível (", e.message, ") → IA local"); return pedirIAlocal(texto); });
  }
  // 3) fallback: Gemini direto (sem schema — parsing tolerante)
  return pedirIAlocal(texto);
}

function pedirIAlocal(texto) {
  if (!IA_CFG.chave) return Promise.resolve(null);
  const modelo = (IA_CFG.modelo || "gemini-3.6-flash").replace("gemini-2.0-flash", "gemini-3.6-flash");
  const listaServicos = Object.keys(PREÇOS).join("; ");
  const prompt = (
    "Você é o assistente de uma serralheria que trabalha com AÇO GALVANIZADO e INOX. " +
    "Serviços: " + listaServicos + ". " +
    "Mensagem do cliente: " + JSON.stringify(texto) + ". " +
    "Analise e responda SOMENTE com JSON: " +
    '{"servico": "nome exato de um serviço da lista (ou null)", "intencao": "pedido | duvida | negociacao | agendamento | irrelevante | saudacao | despedida | sim | nao | humano", "medida": <número ou null>, "material": "inox | galvanizado | null", "resposta_natural": "frase curta de atendente ou null", "encaminhar_humano": true|false}. ' +
    "Se a mensagem não for um pedido nem dúvida sobre os serviços da serralheria, retorne intencao 'irrelevante' e servico null. Nunca invente serviço fora da lista."
  );
  const url = "https://generativelanguage.googleapis.com/v1beta/models/" + modelo + ":generateContent?key=" + IA_CFG.chave;
  return fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    agent: proxyAgent,
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 600 },
    }),
  })
    .then(r => r.json())
    .then(out => {
      try {
        const txt = (out.candidates?.[0]?.content?.parts?.[0]?.text || "").replace(/```json|```/g, "").trim();
        if (!txt) return null;
        const o = JSON.parse(txt);
        return {
          servico: normalizarNomeIA(o.servico),
          medida: (o.medida === null || o.medida === "null" || o.medida === "indefinida") ? null : o.medida,
          material: /inox/i.test(o.material || "") ? "inox" : /galvaniz/i.test(o.material || "") ? "galvanizado" : null,
          intencao: MAPA_INTENCAO_IA[o.intencao] !== undefined ? MAPA_INTENCAO_IA[o.intencao] : null,
          resumo: o.resumo || o.extra || null,
          resposta_natural: o.resposta_natural || null,
          encaminhar_humano: !!o.encaminhar_humano,
          confiavel: o.confiavel !== undefined ? !!o.confiavel : true,
          fonte: "ia-local",
        };
      } catch (e) {
        console.log("⚠️ IA local retornou resposta inválida:", (out.candidates || [{}])[0]?.finishReason || "ok");
        return null;
      }
    })
    .catch(e => { console.log("⚠️ falha na IA local:", e.message); return null; });
}


/* ---------------------------- sessão por cliente -------------------------- */
let sessions = {};
const SESSIONS_FILE = path.join(__dirname, "sessions.json");
try { sessions = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf8")); } catch (e) {}

function saveSessions() {
  try { fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions, null, 2)); } catch (e) {}
}

function get(jid) {
  sessions[jid] = sessions[jid] || { data: {}, atend_humano: false };
  saveSessions();
  return sessions[jid];
}

/* --------------------------------- utils ---------------------------------- */
function fmtBRL(v) {
  const s = v.toFixed(2).replace(".", ",");
  return "R$ " + s;
}

function getPrecoExtra(nome) {
  const e = (CFG.extras || []).find(x => x.nome === nome);
  return e ? e.preco : 0;
}

/* ==================== MOTOR DE LINGUAGEM NATURAL ========================= */

// 1) DETECÇÃO DE SERVIÇO — cada serviço tem apelidos que um cliente usaria
const APELIDOS_SERVICO = {
  "Portão (correr ou basculante)": [
    "portao", "portão", "portoes", "portões", "portao de correr", "portão de correr",
    "basculante", "portao automatico", "portão automático", "portao eletronico",
    "portão eletrônico",
  ],
  "Grade / Muro em grade": [
    "grade", "grades", "muro em grade", "muro com grade", "alambrado",
  ],
  "Estrutura metálica / Mezanino": [
    "estrutura", "estrutura metalica", "estrutura metálica", "mezanino", "galpao",
    "galpão", "cobertura metalica", "cobertura metálica", "cobertura metalica",
  ],
  "Corrimão / Guarda-corpo": [
    "corrimao", "corrimão", "guarda corpo", "guarda-corpo", "guarda corpo de", "guarda-corpo de",
  ],
  "Escada metálica": [
    "escada", "escadas", "escada metalica", "escada metálica", "escada caracol",
  ],
  "Cobertura / Telhado metálico": [
    "cobertura", "telhado", "telha", "toldo", "pergola", "pergóla",
    "cobertura metalica", "telhado metalico",
  ],
  "Balcão / Balcão de inox": [
    "balcao", "balcão", "balcões", "bancada", "pia", "pia de cozinha",
    "cozinha industrial", "balcao de cozinha", "balcão de cozinha",
    "coifa", "capela", "exaustor", "coifa de inox", "coifa industrial",
  ],
  "Letreiro / Placa de ferro": [
    "letreiro", "letras caixa", "letra caixa", "placa", "placa de ferro", "logotipo",
    "totem", "fachada", "identidade visual",
  ],
  "Portão de garagem / Portinha": [
    "portao de garagem", "portão de garagem", "portinha", "portinhao", "portinhão",
    "portao social", "portão social", "guarita", "guarita de portao", "guarita de portão",
  ],
  "Porta de aço": [
    "porta de aco", "porta de aço", "portas de aco", "portas de aço",
    "porta aco", "porta aço", "porta corta fogo", "porta de ferro",
  ],
  "Pérgola / Cobertura de garagem": [
    "pergola", "pérgola", "pergolado", "cobertura de garagem", "cobertura pra varanda",
    "cobertura para varanda", "toldo retratil", "toldo retrátil", "varanda coberta",
  ],
  // "outro/outros" removidos: quem decide serviços genéricos agora é a IA
  "Outros (descrever na conversa)": [
    "orcamento de outro",
  ],
};

// 2) PALAVRAS de intenção — o que o cliente quer com a conversa
const INTENCOES = {
  saudacao: ["oi", "ola", "olá", "oie", "bom dia", "boa tarde", "boa noite", "opa", "hello", "hi", "hey", "e ai", "salve", "boas"],
  orcamento: ["orcamento", "orçamento", "preco", "preço", "valor", "quanto", "quanto fica", "quanto custa", "custa", "cotacao", "cotação", "cotar", "orcar", "orçar", "pedido"],
  humano: ["humano", "atendente", "pessoa", "atendimento", "falar com", "falar com voce", "falar com você", "real", "gerente", "responsavel", "responsável", "combinar", "agendar", "visita", "visita tecnica", "visita técnica", "medicao", "medição", "medir", "fechar", "contratar", "agendar horario", "agendar horário", "marcar", "marcar horario", "marcar horário", "reuniao", "reunião"],
  horario: ["horario", "horário", "horarios", "horários", "funcionamento", "expediente", "aberto", "abertos", "que horas", "quando", "funciona"],
  local: ["onde", "endereco", "endereço", "atende", "atende onde", "regiao", "região", "bairro", "cidade", "localizacao", "localização", "voce atende", "você atende", "fica onde", "atende onde"],
  material: ["material", "galvanizado", "inox", "aco", "aço", "ferro", "aluminio", "alumínio", "qual material", "qual a diferenca", "qual a diferença", "diferenca entre", "diferença entre", "enferuja", "enferruja", "ferrugem", "durabilidade"],
  garantia: ["garantia", "garantias", "manutencao", "manutenção"],
  despedida: ["obrigado", "obrigada", "valeu", "vlw", "agradeco", "agradeço", "ate mais", "até mais", "flw", "falou", "tchau"],
  sim: ["sim", "ok", "combinado", "com certeza", "pode ser", "ta bom", "tá bom", "top", "perfeito", "pode ser sim", "bora", "show", "fechou", "quero sim"],
  nao: ["nao", "não", "n", "nop", "deixa pra la", "depois", "desiste", "desisto", "nao quero", "não quero", "nada"],
  ta_caro: ["ta caro", "tá caro", "muito caro", "ficou caro", "caro demais"],
};

function normalizar(texto) {
  return (texto || "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // remove acentos
    .trim();
}

function detectarServico(texto) {
  const t = normalizar(texto);
  let melhor = null;
  // primeiro busca por apelidos específicos; "outros" fica como fallback
  let melhorEspecifico = null;
  for (const [servico, apelidos] of Object.entries(APELIDOS_SERVICO)) {
    for (const apelido of apelidos) {
      if (t.includes(apelido)) {
        if (servico === "Outros (descrever na conversa)") {
          melhor = servico;
        } else if (!melhorEspecifico || apelido.length > normalizar(melhorEspecifico).length) {
          melhorEspecifico = servico;
        }
        break;
      }
    }
  }
  return melhorEspecifico || melhor;
}

function detectarMaterial(texto) {
  const t = normalizar(texto);
  if (t.includes("inox")) return "inox";
  if (t.includes("galvanizado") || t.includes("galvan")) return "galvanizado";
  return null;
}

// Captura medida: "3m", "3 m", "3,5 metros", "6 m2", "10 metros quadrados", "2x3"
function detectarMedida(texto) {
  const t = normalizar(texto);
  // área: "3x2", "3 por 2", "3 x 2" (com ou sem unidade)
  const areaM = t.match(/(\d+[.,]?\d*)\s*[xX]\s*(\d+[.,]?\d*)\s*(m2|m2|m|\s|$)/);
  if (areaM) {
    const a = parseFloat(areaM[1].replace(",", "."));
    const b = parseFloat(areaM[2].replace(",", "."));
    if (!isNaN(a) && !isNaN(b)) return a * b;
  }
  // unidade com medida: "3,5 metros", "6 m2", "200 cm"
  const m = t.match(/(\d+[.,]?\d*)\s*(m2|m²|metros quadrados|metro quadrado|m|metros|metro|cms|cm)/);
  if (m) {
    let v = parseFloat(m[1].replace(",", "."));
    const un = m[2];
    if (un === "cm" || un === "cms") v = v / 100;
    return isNaN(v) ? null : v;
  }
  // número solto (cliente só manda "3" depois de pergunta de medida)
  const numM = t.match(/^(\d+[.,]?\d*)$/);
  if (numM) {
    const v = parseFloat(numM[1].replace(",", "."));
    return isNaN(v) ? null : v;
  }
  return null;
}

function detectarExtras(texto) {
  const t = normalizar(texto);
  // Se o cliente está pedindo visita/agendamento, não marca "Medição técnica" como extra
  const intenT = detectarIntencao(texto);
  const escol = [];
  const mapa = {
    "Pintura eletrostática": ["pintura", "pintar", "pintado"],
    "Instalação inclusa": ["instalacao", "instalação", "instalar", "montagem"],
    "Fechadura / automação básica": ["fechadura", "automacao", "automação", "portao automatico", "controle remoto"],
    "Medição técnica presencial": ["medicao", "medição"],
  };
  for (const [nome, kw] of Object.entries(mapa)) {
    for (const k of kw) if (t.includes(k)) { escol.push(nome); break; }
  }
  return escol;
}

// Intenções "fortes": quando o cliente faz uma pergunta específica (horário, local,
// garantia etc.), ela ganha do fechamento automático de orçamento em andamento.
const INTENCOES_FORTES = ["horario", "local", "garantia", "material", "humano"];

function detectarIntencao(texto) {
  const t = normalizar(texto);
  const hits = {};
  for (const [inten, kws] of Object.entries(INTENCOES)) {
    for (const k of kws) {
      // palavras curtas (1-2 letras) só casam como palavra inteira —
      // evita "n" dentro de "precisando", "inox", etc.
      const regex = k.length <= 2
        ? new RegExp("(^|[^a-z0-9])" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "($|[^a-z0-9])")
        : null;
      if (regex ? regex.test(t) : t.includes(k)) hits[inten] = (hits[inten] || 0) + 1;
    }
  }
  if (t === "boa" || t === "oi" || t === "opa" || t === "salve") hits.saudacao = (hits.saudacao || 0) + 1;
  // empate de hits: intenção forte (horário, local, garantia, material, humano)
  // vence sobre as fracas — "boa tarde, funcionam no sábado?" é pergunta, não só saudação
  const ordenadas = Object.entries(hits).sort((a, b) => {
    if (a[1] !== b[1]) return b[1] - a[1];
    const fa = INTENCOES_FORTES.includes(a[0]) ? 0 : 1;
    const fb = INTENCOES_FORTES.includes(b[0]) ? 0 : 1;
    return fa - fb;
  });
  if (!ordenadas.length) return null;
  return ordenadas[0][0];
}

/* ---------------------------------- bot ------------------------------------ */
let sock;
let online = false;
let reiniciando = false;

async function enviar(jid, texto) {
  if (!sock) return;
  try {
    await sock.sendMessage(jid, { text: texto }, { statusJidList: undefined });
    await new Promise(r => setTimeout(r, 700));
  } catch (e) {
    console.log("erro enviar:", e.message);
    try {
      await new Promise(r => setTimeout(r, 3000));
      await sock.sendMessage(jid, { text: texto });
    } catch (e2) {
      console.log("erro enviar (2ª tentativa):", e2.message);
    }
  }
}

function notificarHumano(msg) {
  if (!sock) return;
  sock.sendMessage(HUMANO_NUM.split("@")[0] + "@s.whatsapp.net", { text: msg })
    .catch(e => console.log("erro notificar humano:", e.message));
}

/* ----------------------------- RESPOSTAS NATURAIS ------------------------- */

function saudacao() {
  const h = new Date().getHours();
  let periodo = "Boa noite";
  if (h >= 5 && h < 12) periodo = "Bom dia";
  else if (h >= 12 && h < 18) periodo = "Boa tarde";
  // Nome da loja vem do banco (whatsapp_bots) — reflete alterações do Super Admin (cache de 5 min)
  const nome = (_cacheBot && _cacheBot.loja_nome) ? String(_cacheBot.loja_nome).trim() : EMPRESA;
  console.log("[saudacao] usando nome:", nome);
  return (
    `${periodo}! 👋 Aqui é da *${nome}* — a gente trabalha com *aço galvanizado e inox*:\n` +
    `portões, grades, estruturas, escadas, coberturas, balcões de inox e muito mais.\n\n` +
    `Me conta o que você precisa que eu já te passo uma estimativa, sem enrolação. 😊`
  );
}

function saudacaoReativa(intencao) {
  const nome = (_cacheBot && _cacheBot.loja_nome) ? String(_cacheBot.loja_nome).trim() : EMPRESA;
  console.log("[saudacaoReativa] usando nome:", nome);
  if (intencao === "orcamento") {
    return (
      `Que bom! Aqui é da *${nome}*. Me diz o que você precisa — por exemplo:\n\n` +
      `_"quero um portão de 3 metros"_ ou _"grade de uns 8 m² em inox"_ — e já te passo os valores. 😊`
    );
  }
  return saudacao();
}

function calcularOrcamento(servico, material, medida, totalExtras) {
  const cat = PREÇOS[servico];
  if (!cat) return [null, null, null];
  const preco = cat.preco_por_m2 || cat.preco_por_un;
  let desc;
  let baseMin, baseMax;
  if (cat.por_m2) {
    const area = Math.max(medida, cat.area_minima || 1);
    baseMin = preco[0] * area; baseMax = preco[1] * area;
    desc = `área de ~${area.toFixed(1)} m²`;
  } else {
    const n = Math.max(Math.round(medida), 1);
    baseMin = preco[0] * n; baseMax = preco[1] * n;
    desc = `${n} unidade(s)`;
  }
  const mult = material === "inox" ? 1.2 : 1.0;
  return [
    Math.round((baseMin * mult + totalExtras) * 100) / 100,
    Math.round((baseMax * mult + totalExtras) * 100) / 100,
    desc,
  ];
}

function resumoAtual(s) {
  const d = s.data || {};
  const partes = [];
  if (d.servico) partes.push(`*Serviço:* ${d.servico}`);
  if (d.material) partes.push(`*Material:* ${d.material === "inox" ? "Inox ✨" : "Aço galvanizado 🔩"}`);
  if (d.medida) partes.push(`*Medida:* ${d.medida}`);
  if (d.extras && d.extras.length) partes.push(`*Extras:* ${d.extras.map(e => e[0]).join(", ")}`);
  return partes.join("\n");
}

function calcularEEnviarOrcamento(jid, s) {
  const d = s.data;
  const extrasTotal = (d.extras || []).reduce((acc, e) => acc + (e[1] || 0), 0);
  const [vMin, vMax, desc] = calcularOrcamento(d.servico, d.material || "galvanizado", d.medida, extrasTotal);
  d.v_min = vMin; d.v_max = vMax;
  saveSessions();

  const extrasTxt = (d.extras || []).length
    ? (d.extras || []).map(e => `• ${e[0]}: ${fmtBRL(e[1])}`).join("\n") + "\n"
    : "";
  const resumo = resumoAtual(s);

  const msg = (
    `📋 *Orçamento pronto!* ✅\n\n${resumo}\n${extrasTxt}\n` +
    `${desc.charAt(0).toUpperCase() + desc.slice(1)}\n\n` +
    `*Valor estimado: ${fmtBRL(vMin)} a ${fmtBRL(vMax)}*\n\n` +
    `⚠️ É uma estimativa inicial — o valor final é confirmado na *visita técnica gratuita*.\n\n` +
    `Quer que eu já te encaminhe pro responsável pra *combinar a visita* e fechar o serviço? 😊`
  );
  return enviar(jid, msg);
}

function handoff(jid, s, tipo = "humano") {
  s.atend_humano = true;
  saveSessions();
  const d = s.data || {};
  let msgHumano, msgCliente;
  if (tipo === "visita") {
    const material = d.material === "inox" ? "Inox" : "Aço galvanizado";
    const valor = d.v_min ? `${fmtBRL(d.v_min)} a ${fmtBRL(d.v_max)}` : "não calculado";
    msgHumano = (
      `🔔 *Novo pedido de VISITA TÉCNICA*\n\n` +
      `Cliente: ${jid.split("@")[0]}\n` +
      `Serviço: ${d.servico || "a definir"}\n` +
      `Material: ${material}\n` +
      `Medida: ${d.medida || "a definir"}\n` +
      `Orçamento estimado: ${valor}\n` +
      `O cliente está aguardando para combinar o horário. ✅`
    );
    msgCliente = (
      "✅ Perfeito! Encaminhei seu pedido pra nossa equipe. " +
      "Um técnico vai te chamar aqui no WhatsApp em instantes pra combinar o melhor horário — " +
      "a visita técnica é *gratuita* e sem compromisso. 😊\n\n" +
      "Enquanto isso, me pergunta qualquer coisa!"
    );
  } else {
    msgHumano = (
      `🔔 *Cliente quer falar com um humano*\n\n` +
      `Cliente: ${jid.split("@")[0]}\n` +
      `Contexto: ${JSON.stringify(d).slice(0, 500)}\n` +
      `Assuma o atendimento por favor. ✅`
    );
    msgCliente = (
      "✅ Tá certo! Vou te encaminhar pra nossa equipe agora — eles vão te responder aqui no WhatsApp rapidinho. 😊\n\n" +
      "Se precisar de outro orçamento comigo, é só chamar!"
    );
  }
  notificarHumano(msgHumano);
  return enviar(jid, msgCliente);
}

/* ==================== NÚCLEO: PROCESSAR MENSAGEM =========================== */

async function processar(jid, texto) {
  const t = (texto || "").trim();
  const s = get(jid);
  const d = s.data = s.data || {};

  // 1) Detectar intenções e entidades no texto livre
  const intencao = detectarIntencao(t);
  const servicoNovo = detectarServico(t);
  const materialNovo = detectarMaterial(t);
  const medidaNova = detectarMedida(t);
  const extrasNovos = (intencao !== "humano") ? detectarExtras(t) : [];

  // Aplica entidades detectadas na sessão (qualquer estado da conversa)
  // "corpo" sozinho NUNCA casa com serviço (evita "guarda corpo" virar falso-positivo)
  // Bloqueia APENAS "corpo" genuinamente isolado (ex.: "tô precisando de corpo") —
  // "guarda corpo" e "guarda-corpo" CASAM normalmente (keyword exige "guarda")
  const corpoIsolado = /(^|\s)corpo\b/.test(normalizar(t)) && !/guarda\s?corpo/.test(normalizar(t));
  if (servicoNovo && servicoNovo !== d.servico && !(corpoIsolado && servicoNovo === "Corrimão / Guarda-corpo")) {
    d.servico = servicoNovo; d.medida = null; d.v_min = null;
  }
  if (materialNovo) d.material = materialNovo;
  if (medidaNova !== null && medidaNova > 0 && isFinite(medidaNova)) d.medida = medidaNova;
  // sanidade: jamais deixar medida virar texto ou NaN (nem em dados antigos salvos)
  if (typeof d.medida !== "number" || !isFinite(d.medida)) d.medida = null;
  if (!d.servico) { d.medida = null; d.material = null; }
  if (d.medida !== null && !d.servico) d.medida = null;
  if (extrasNovos.length) {
    d.extras = extrasNovos.map(n => [n, getPrecoExtra(n)]);
  }
  saveSessions();

  // 1.5) Pergunta informativa forte (horário, local, garantia, materiais) —
  // ganha quando a mensagem é SÓ uma dúvida (sem pedido novo de serviço)
  // "material" é intenção forte (dúvida), mas quando o bot está esperando o material
  // do orçamento, a palavra "inox/galvanizado" é RESPOSTA — não dúvida
  const aguardandoMaterial = d.servico && d.medida && !d.material;
  if (INTENCOES_FORTES.includes(intencao) && !servicoNovo && !(intencao === "material" && aguardandoMaterial)) {
    if (intencao === "horario") return enviar(jid, CFG.horarios + (d.servico ? "\n\nE o orçamento do seu " + d.servico + " continua de pé — é só me dizer quando quiser fechar. 😊" : "\n\nQuer um orçamento pra algum serviço?"));
    if (intencao === "local") return enviar(jid,
      "📍 A gente atende em *toda a região*!\n\n" +
      "Me passa seu endereço ou bairro que eu confirmo a disponibilidade — e a visita técnica é *gratuita*, sem compromisso. 😊"
    );
    if (intencao === "garantia") {
      return enviar(jid,
        "🛡️ *Garantia*: todos os nossos trabalhos têm *garantia de 1 ano* contra defeitos de fabricação.\n\n" +
        "Aço galvanizado e inox são materiais de altíssima durabilidade — com manutenção básica, seu portão dura décadas. " +
        (d.servico ? "E o orçamento do seu " + d.servico + " continua salvinho aqui, é só dizer quando quiser fechar. 😊" : "Quer um orçamento pra algum serviço?")
      );
    }
    // Se o orçamento já está completo, "inox/galvanizado" avulso não é dúvida —
    // é reforço; não repetir a página de materiais, apenas confirmar e convidar a fechar
    // material forte com orçamento completo: se a mensagem TROUXE o material, fecha;
    // se o material já estava anotado, apenas confirma
    if (intencao === "material" && d.servico && d.medida && d.material)
      return materialNovo ? calcularEEnviarOrcamento(jid, s) :
        enviar(jid, `O material já tá anotado: *${d.material}*! 🛠️\n\nSeu orçamento continua de pé — é só me dizer *sim* que eu te encaminho pra fechar. 😊`);
    if (intencao === "material") return enviar(jid, CFG.materiais_info + "\n\nQuer um orçamento pra algum serviço?");
    if (intencao === "humano") return handoff(jid, s, d.servico ? "visita" : "humano");
  }

  // 2) Orçamento completo: serviço + medida + material → fecha na hora
  if (d.servico && d.medida && d.material) {
    if (intencao === "despedida") {
      d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
      saveSessions();
      return enviar(jid, "Obrigado por falar com a gente! 👋 Qualquer coisa, chama aqui. 😊");
    }
    if (intencao === "sim") return handoff(jid, s, "visita");
    if (intencao === "nao") {
      saveSessions();
      return enviar(jid, `Ok, sem problema! 👌 O orçamento do ${d.servico} fica salvinho aqui — é só me chamar de novo quando quiser fechar. 😊`);
    }
    if (intencao === "ta_caro") {
      saveSessions();
      return enviar(jid,
        `Entendi! 😊 Lembrando que esse é só um *valor estimado* — o valor final é confirmado na *visita técnica gratuita*, sem compromisso.\n\n` +
        `Posso te encaminhar pro responsável pra marcar a visita?`
      );
    }
    // Palavra avulsa (ex.: "inox" depois do orçamento pronto) → não repete orçamento
    const semEntidadeNova = !servicoNovo && !materialNovo && medidaNova === null && !extrasNovos.length;
    if (semEntidadeNova) {
      return enviar(jid, `Já tá tudo anotado aqui: ${d.servico}, ${d.medida} ${PREÇOS[d.servico]?.por_m2 ? "m²" : "metros"}, ${d.material}. É só me dizer *sim* que eu te encaminho pra fechar. 😊`);
    }
    return calcularEEnviarOrcamento(jid, s);
  }

  // 3) Tem serviço mas falta medida ou material
  if (d.servico && !d.medida) {
    if (intencao === "despedida") {
      d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
      saveSessions();
      return enviar(jid, "Obrigado por falar com a gente! 👋 Qualquer coisa, chama aqui. 😊");
    }
    const por = PREÇOS[d.servico]?.por_m2 ? "m²" : "metros";
    return enviar(jid,
      `👍 *${d.servico}*, anotado!\n\n` +
      `Me passa a medida aproximada em ${por} — pode ser tipo *"3 metros"* ou *"2x4"*. 😊`
    );
  }

  if (d.servico && d.medida && !d.material) {
    if (intencao === "despedida") {
      d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
      saveSessions();
      return enviar(jid, "Sem problema! Quando precisar, é só chamar. 😊");
    }
    return enviar(jid,
      `E o material: *aço galvanizado* 🔩 (mais econômico e resistente) ou *inox* ✨ (mais bonito e não enferruja)?\n\n` +
      `É só responder "inox" ou "galvanizado".`
    );
  }

  // 4) Sem serviço ainda: intenção inicial
  if (intencao === "saudacao" || intencao === "orcamento") {
    d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
    saveSessions();
    return enviar(jid, saudacaoReativa(intencao));
  }

  if (intencao === "sim") {
    const ativas = d.servico || d.medida || d.material;
    if (!ativas) {
      saveSessions();
      return enviar(jid, saudacao());
    }
    if (d.servico && d.medida && d.material) return handoff(jid, s, "visita");
    return enviar(jid, `Quer que eu já te encaminhe pro responsável pra fechar o ${d.servico}? 😊`);
  }

  if (intencao === "nao") {
    // recusa não apaga o orçamento: cliente pode mudar de ideia depois
    const ativas = d.servico || d.medida || d.material;
    if (!ativas) {
      saveSessions();
      return enviar(jid, "Sem problema! Quando precisar, é só chamar. 😊");
    }
    saveSessions();
    return enviar(jid, `Ok, sem problema! 👌 O orçamento do ${d.servico} fica salvinho aqui — é só me chamar de novo quando quiser fechar. 😊`);
  }

  if (intencao === "despedida") {
    d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
    saveSessions();
    return enviar(jid, "Obrigado por falar com a gente! 👋 Qualquer coisa, chama aqui. Estamos à disposição! 😊");
  }

  // 5) IA — entende pedidos fora do catálogo local (ex.: coifa, letreiro, pérgola...)
  // Só consome quota da IA quando o detector local não resolveu nada
  const intenResolvida = intencao && ["saudacao", "despedida", "sim", "nao", "ta_caro", "chamar_humano", "agendar_visita"].includes(intencao);
  if (IA_CFG && IA_CFG.habilitada && !intenResolvida && !d.servico) {
    try {
      const ia = await pedirIA(jid, t);
      if (ia) {
        // entidades da IA (sobrepõem o detector local: a IA lê o contexto inteiro)
        if (ia.servico) { d.servico = ia.servico; d.medida = null; d.v_min = null; }
        if (ia.medida !== null && ia.medida !== undefined) {
          const mIA = parseFloat(ia.medida);
          if (isFinite(mIA) && mIA > 0) d.medida = mIA;
        }
        if (ia.material) d.material = ia.material;
        saveSessions();
        const intencaoIA = ia.intencao;
        // encaminhamento humano direto
        if (ia.encaminhar_humano) return handoff(jid, s, d.servico ? "visita" : "humano");
        // intenção da IA
        if (intencaoIA === "humano") return handoff(jid, s, d.servico ? "visita" : "humano");
        if (intencaoIA === "pergunta_info") {
          const nat = ia.resposta_natural || "Pode me dar mais detalhes do que você precisa? Assim te ajudo melhor! 😊";
          return enviar(jid, nat + (d.servico ? "\n\nE o orçamento do seu " + d.servico + " continua de pé — é só me dizer quando quiser fechar. 😊" : ""));
        }
        if (intencaoIA === "saudacao") {
          d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
          saveSessions();
          return enviar(jid, ia.resposta_natural || saudacao());
        }
        if (intencaoIA === "despedida") {
          d.servico = null; d.medida = null; d.material = null; d.extras = null; d.v_min = null;
          saveSessions();
          return enviar(jid, ia.resposta_natural || "Obrigado por falar com a gente! 👋 Qualquer coisa, chama aqui. 😊");
        }
        if (intencaoIA === "sim") {
          const ativas = d.servico || d.medida || d.material;
          if (!ativas) return enviar(jid, ia.resposta_natural || saudacao());
          if (d.servico && d.medida && d.material) return handoff(jid, s, "visita");
          return enviar(jid, ia.resposta_natural || (`Quer que eu já te encaminhe pro responsável pra fechar o ${d.servico}? 😊`));
        }
        if (intencaoIA === "nao") {
          const ativas = d.servico || d.medida || d.material;
          if (!ativas) return enviar(jid, ia.resposta_natural || "Sem problema! Quando precisar, é só chamar. 😊");
          saveSessions();
          return enviar(jid, ia.resposta_natural || (`Ok, sem problema! 👌 O orçamento do ${d.servico} fica salvinho aqui — é só me chamar de novo quando quiser fechar. 😊`));
        }
        if (intencaoIA === "ta_caro") return enviar(jid, ia.resposta_natural || ("Entendo! Nossos valores são os mais competitivos da região e incluem material de qualidade com *garantia de 1 ano*. 🛡️\n\nA visita técnica é *gratuita* — o técnico avalia o projeto e fecha o melhor preço. Quer agendar?"));
        // orcamento / irrelevante / null — usa a resposta natural se existir
        if (ia.resposta_natural) return enviar(jid, ia.resposta_natural + (d.servico ? "\n\n📋 " + resumoAtual(s) : ""));
      }
    } catch (e) {
      console.log("⚠️ erro na IA:", e.message);
    }
  }

  // registro de desempenho: grava a conversa no painel da loja (SmartHubly)
  try {
    const tel = jid.replace(/@.*/, "");
    const bot = await botDaLoja(tel, { refresh: true });
    if (bot && bot.id) {
      const payload = {
        bot_id: bot.id, telefone_cliente: tel, mensagem: t,
        resposta_bot: ia && ia.resposta_natural ? String(ia.resposta_natural).slice(0, 800) : null,
        intencao: ia ? ia.intencao || null : null,
        item_catalogo: ia && ia.servico ? ia.servico : null,
        servico: d.servico || null,
        preco_estimado: d.v_min ? `R$ ${d.v_min}${d.v_max && d.v_max !== d.v_min ? " a R$ " + d.v_max : ""}` : null,
        status_orcamento: d.servico ? (d.medida && d.material ? "pendente" : "aberto") : "aberto",
        humano_encaminhado: !!(ia && ia.encaminhar_humano),
      };
      const REST = (CFG.ia && CFG.ia.supabase_url) || IA_URL_BASE();
      if (REST) {
        fetch(REST + "/rest/v1/bot_conversas", {
          method: "POST", agent: proxyAgent,
          headers: { "Content-Type": "application/json", "apikey": SR_KEY, "Authorization": "Bearer " + SR_KEY, "Prefer": "return=minimal" },
          body: JSON.stringify(payload),
                }).catch(e => console.log("⚠️ log de conversa falhou:", e.message));
      }
    }
  } catch (e) { /* nunca bloquear a resposta do bot por causa do log */ }

  // 6) Fallback acolhedor — usa o perfil da loja (banco) pra não ficar "cego" sem a IA
  try {
    const tel = jid.replace(/@.*/, "");
    const bot = await botDaLoja(tel, { refresh: true });
    if (bot && bot.mensagem_boas_vindas) {
      return enviar(jid,
        `🤖 Nossa IA de entendimento está em manutenção no momento, mas estou aqui! 😊\n\n` +
        bot.mensagem_boas_vindas +
        `\n\nOu me diga em uma frase o que precisa: medida, material (galvanizado ou inox) e o que quer construir — já te passo uma estimativa!`
      );
    }
  } catch (e) { /* ignora e cai no fallback genérico */ }
  return enviar(jid,
    `Hmm, não entendi direito 😅\n\n` +
    `Me diz o que você precisa em uma frase, tipo:\n` +
    `• _"quero um portão de 3 metros em inox"_ (já te passo o valor na hora)\n` +
    `• _"quanto custa uma grade?"_\n` +
    `• _"quero agendar uma visita"`
  );
}

/* ---------------------------- conexão WhatsApp ----------------------------- */
async function conectar() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  sock = makeWASocket({
    auth: state,
    browser: Browsers.ubuntu("Chrome"),
    printQRInTerminal: true,
    syncFullHistory: false,
    shouldSyncHistoryMessage: () => false,
    connectTimeoutMs: 30000,
    keepAliveIntervalMs: 10000,
    markOnlineOnConnect: true,
    agent: proxyAgent,
    fetchAgent: proxyAgent,
  });

  sock.ev.on("creds.update", saveCreds);

  // Número do próprio bot, obtido da sessão (me.id) — não depende do config.json local.
  // update.sh preserva o config do usuário, então bot_telefone do config pode faltar em installs antigos.
  setInterval(() => {
    try {
      const meu = sock?.user?.id;
      if (meu) {
        const tel = String(meu).match(/(\d{8,15})/);
        CFG.bot_telefone = tel ? tel[1] : String(meu).replace(/:\d+$/, "").replace(/@.*/, "");
      }
    } catch (e) {}
  }, 30000);

  // Recarrega o perfil da loja a cada 30s em background — mudanças do Super Admin
  // chegam ao bot mesmo que ninguém esteja conversando no momento.
  setInterval(() => {
    try {
      const tel = botTelefoneAtual();
      if (tel) botDaLoja(tel, { refresh: true, silencioso: true });
    } catch (e) {}
  }, 30000);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log("\n=== QR CODE — escaneie com o WhatsApp do número do bot ===");
      QRCode.generate(qr, { small: true });
      console.log("=========================================================\n");
      return;
    }

    if (connection === "open") {
      online = true;
      console.log("✅ Bot conectado e online 24/7!");
      try {
        // carrega o perfil da loja do banco logo na conexão (nome correto desde a 1ª mensagem)
        const tel = ((sock?.user?.id || "").match(/(\d{8,15})/) || [])[1] || (sock?.user?.id || "").replace(/:\d+$/, "").replace(/@.*/, "");
        if (tel) await botDaLoja(tel);
        console.log("🏪 Perfil da loja carregado do banco.");
      } catch (e) {
        console.log("⚠️ perfil da loja:", e.message);
      }
      try {
        await sock.sendPresenceUpdate("available");
      } catch (e) {
        console.log("erro presença:", e.message);
      }
      return;
    }

    if (connection === "close") {
      online = false;
      const reason = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = reason === DisconnectReason.loggedOut;
      console.log("conexão fechada:", lastDisconnect?.error?.message, "código:", reason);

      if (loggedOut) {
        console.log("Sessão encerrada pelo WhatsApp. Apague a pasta auth/ e reinicie.");
        process.exit(1);
      }

      if (!reiniciando) {
        reiniciando = true;
        setTimeout(async () => {
          reiniciando = false;
          try {
            await sock.ws.close();
          } catch (e) {}
          conectar();
        }, 5000);
      }
    }

    if (connection === "connecting") {
      console.log("🔄 reconectando ao WhatsApp...");
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (!messages || !messages.length) return;
    for (const m of messages) {
      const key = m.key || {};
      console.log("[MSG]", type, key.remoteJid, "fromMe:", key.fromMe);

      if (key.fromMe) continue;
      const texto = m.message?.conversation || m.message?.extendedTextMessage?.text;
      if (!texto) continue;
      console.log("[MSG-TEXTO]:", texto.slice(0, 80));
      try {
        await processar(key.remoteJid, texto);
      } catch (e) {
        console.log("erro processar:", e.message);
      }
    }
  });

  sock.ev.on("messaging-history.set", (data) => {
    const n = data?.chats?.length ?? 0;
    console.log(`📥 histórico: ${n} conversas carregadas`);
  });

  // 🛡️ Safety flush: se o Baileys ficar preso no buffer interno (>15s), força a liberação.
  setInterval(() => {
    try {
      if (sock.ev.isBuffering && sock.ev.isBuffering()) {
        console.log("🛡️ forçando liberação de mensagens presas no buffer...");
        sock.ev.flush();
      }
    } catch (e) {}
  }, 15000);
}

conectar().catch(e => { console.error("erro fatal:", e); process.exit(1); });
