#!/bin/bash
# Inicia o bot (com reinício automático se cair)
# Mantém o celular acordado para não pausar o bot em segundo plano
cd ~/bot-termux
termux-wake-lock 2>/dev/null

# Auto-atualização: checa nova versão na nuvem antes de iniciar
./update.sh

while true; do
  echo "[$(date)] iniciando bot..."
  node bot.js
  echo "[$(date)] bot caiu — reiniciando em 5s..."
  sleep 5
done
