# Como usar o bot em redes corporativas (Wi-Fi de empresa)

O WhatsApp pode derrubar a conexão em redes corporativas que cortam conexões
WebSocket longas. Este guia explica as soluções.

## Solução 1 — VPN Cloudflare WARP (recomendada, mais fácil)

1. Instale o app **1.1.1.1** (da Cloudflare) na Play Store.
2. Abra o app e ative o **WARP** (botão grande "Conectar").
3. No Termux, reinicie o bot:

```
pkill -f "node bot.js"; sleep 2; cd ~/bot-termux && ./start.sh
```

O WARP encapsula todo o tráfego em UDP comum, que firewalls corporativos
quase nunca bloqueiam. O bot não precisa de nenhuma configuração extra —
o WARP atua no nível do celular.

## Solução 2 — Proxy HTTPS/SOCKS5 (para quem tem proxy pago/grátis)

Se você tem um servidor proxy (HTTPS ou SOCKS5), ative no bot assim:

```
cd ~/bot-termux
node ativar_proxy.js "https://usuario:senha@host:porta"
pkill -f "node bot.js"; sleep 2; ./start.sh
```

O bot vai imprimir `🔗 Bot usando proxy: ...` ao iniciar, confirmando que
todo o tráfego do WhatsApp passa pelo proxy.

Para desativar o proxy:

```
node -e "const fs=require('fs');const c=JSON.parse(fs.readFileSync('config.json'));delete c.proxy;fs.writeFileSync('config.json',JSON.stringify(c,null,2));console.log('proxy desativado')"
```

## Solução 3 — Trocar de rede

Se possível, use dados móveis da operadora (sem VPN/Rev Hunter) ou um
Wi-Fi residencial. O bot funciona perfeitamente em redes limpas.

## Dicas importantes

- O Rev Hunter e proxies HTTP "internet grátis" NÃO funcionam — o WhatsApp
  detecta e bloqueia conexões via proxy HTTP.
- O WARP (VPN real via WireGuard) funciona porque usa túnel UDP criptografado.
- Mantenha o termux-wake-lock ativo (o start.sh já cuida disso).
- Se a conexão cair, o bot reconecta sozinho em 5 segundos.
