/* serralheria-intent — SmartHubly Workers (Supabase Edge Function) — v5.5
 * Classifica mensagens do WhatsApp (bot multi-tenant, tabela whatsapp_bots).
 * Resolve a loja pelo `telefone_do_bot` enviado pelo bot, injetando
 * loja_nome + segmento da loja no prompt da IA e no fallback sem IA.
 * Portável para Deno: fetch e crypto nativos.
 */

// Chaves Gemini em rotação (plano free AI Studio) — REMOVIDAS em 19/08:
// AIzaSyA6RH... (403 referrer restrito), AIzaSyC26Qb3JyKf7RQ2JZj3b1Rb4xXk0Z3J (key inválida),
// AIzaSyDR5yfaG7OG8sMTUj8kfQEb8T9pN8BM (key inválida)
const KEYS: string[] = [
  "AIzaSyASOPA6l7frTwOUhZmZvTpx2n88JXkPptc",
  "AIzaSyBX6dHQKVJw96EeDBLYgazOxOUpyFxUAmg",
  "AQ.Ab8RN6JnCK8xYOY69s5j87RmGvekDfoNirItvutr3OfuTwCxFw",
];

const SCHEMA = {
  type: "OBJECT",
  properties: {
    servico: { type: "STRING" },
    material: { type: "STRING" },
    medida: { type: "STRING" },
    intencao: { type: "STRING" },
    extra: { type: "STRING" },
    resposta_natural: { type: "STRING" },
    confiavel: { type: "BOOLEAN" },
    encaminhar_humano: { type: "BOOLEAN" },
  },
  required: ["intencao", "confiavel", "encaminhar_humano"],
};
// Supabase do bot (mesmo projeto onde vive a Edge Function):
const SUPA_URL = Deno.env.get("SUPABASE_URL") || "https://qbclplbcdxoyqpmcehnvu.supabase.co";
const SUPA_ANON = Deno.env.get("SUPABASE_ANON_KEY") ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFiY3BsYmNkeG95cXBtY2VobnZ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY2NTk1NjAsImV4cCI6MjEwMjIzNTU2MH0.Qmg4xBNcLhnPYBlB7EWZyRRLHZqSqnAJZCjkHk1Kl78";
// Cache do perfil da loja por 5 min — alterações no Super Admin refletem rápido
const _cache: { ts: number; tel: string; bot: any } = { ts: 0, tel: "", bot: null };
async function perfilLoja(telefoneDoBot: string): Promise<any> {
  if (_cache.tel === telefoneDoBot && _cache.ts + 5 * 60 * 1000 > Date.now() && _cache.bot !== null) return _cache.bot;
  try {
    const url = SUPA_URL + "/rest/v1/whatsapp_bots?telefone=eq." + encodeURIComponent(telefoneDoBot) +
      "&select=id,loja_nome,segmento,mensagem_boas_vindas&limit=1";
    const res = await fetch(url, { headers: { "apikey": SUPA_ANON, "Authorization": "Bearer " + SUPA_ANON } });
    if (!res.ok) return null;
    const rows: any[] = await res.json();
    const bot = (rows && rows[0]) || null;
    if (bot) { _cache.tel = telefoneDoBot; _cache.bot = bot; _cache.ts = Date.now(); }
    return bot;
  } catch { return null; }
}

const SYSTEM_PROMPT =
  "Você é o assistente de INTENÇÕES de um bot WhatsApp de SERRALHERIA (aço galvanizado e inox). " +
  "Serviços da serralheria: portão (correr/basculante), grade/muro em grade, estrutura metálica/mezanino, " +
  "corrimão/guarda-corpo, escada metálica, cobertura/telhado metálico, balcão/balcão de inox, coifa de inox, " +
  "letreiro/placa de ferro, portão de garagem/portinha, porta de aço, pérgola/cobertura de garagem, outros. " +
  "Material: galvanizado ou inox. Responda SEMPRE com JSON puro.";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const mensagem: string = (body?.mensagem || body?.texto || body?.text || "").toString().trim();
  // telefone_do_bot = número do WhatsApp do BOT (loja). O "telefone" do cliente é irrelevante p/ multi-tenant.
  const telefoneDoBot: string = (body?.telefone_do_bot || body?.numero_bot || body?.bot_telefone || "").toString().replace(/\D/g, "");

  if (!mensagem) {
    return corsJson({
      erro: "mensagem vazia",
      intencao: "irrelevante",
      confiavel: false,
      encaminhar_humano: false,
      resposta_natural: "Não recebi nenhuma mensagem. O que você precisa? 😊",
    });
  }

  // Resolve a loja pelo número do bot (se não vier, usa perfil genérico)
  const bot = telefoneDoBot ? await perfilLoja(telefoneDoBot) : null;
  const lojaNome = bot?.loja_nome ? String(bot.loja_nome).trim() : "";
  const segmento = bot?.segmento ? String(bot.segmento).trim() : "";
  const boasVindas = bot?.mensagem_boas_vindas ? String(bot.mensagem_boas_vindas).trim() : "";

  // Contexto da loja injetado no prompt — é isso que faz a IA refletir as edições do Super Admin
  const contextoLoja = lojaNome ?
    "\n\nLoja atendida por este bot: *" + lojaNome + "*" + (segmento ? " (nicho: " + segmento + ")" : "") +
    ".\nSempre se apresente com o nome da loja: " + JSON.stringify(lojaNome) + ". " +
    (boasVindas ? "Perfil institucional da loja: " + JSON.stringify(boasVindas.slice(0, 400)) + ". " : "") +
    "Nunca fale como se fosse outra empresa. " : "";

  const prompt =
    SYSTEM_PROMPT + contextoLoja +
    "\n\nMensagem do cliente: " + JSON.stringify(mensagem) + "\n\n" +
    "Regras:\n" +
    "- intencao: uma de [orcamento, pergunta_info, agendar_visita, chamar_humano, saudacao, despedida, resposta_sim, resposta_nao, negociacao, desconhecido]\n" +
    "- servico: nome exato de um serviço da lista acima (ou string vazia \"\")\n" +
    "- material: \"inox\" | \"galvanizado\" | \"\" conforme o texto do cliente\n" +
    "- medida: número+unidade mencionado (ex \"3m\", \"150cm\") ou string vazia\n" +
    "- extra: resumo curto do pedido ou string vazia\n" +
    "- resposta_natural: frase curta e amigável de atendente no mesmo estilo do cliente (ou string vazia)\n" +
    "- encaminhar_humano: true SE o cliente pediu explicitamente para falar com pessoa/atendente/responsável/agendar\n" +
    "- confiavel: true SE a mensagem é claramente sobre os serviços da serralheria, false caso contrário\n" +
    "- Se a mensagem não tem relação com serralheria (assuntos pessoais, outros negócios, spam), intencao=\"desconhecido\", confiavel=false, resposta_natural=\"\".";

  let lastErr = "";
  let erro429 = 0, tentativasGemini = 0, tudo429 = false;
  // Modelos em cascata (free tier = 20 req/DIA por projeto/modelo — cada projeto/modelo é um "balde" separado):
  // 3.5-flash primeiro (cota livre), 2.5-flash e 3.6-flash como reservas
  const MODELOS: string[] = ["gemini-3.5-flash", "gemini-2.5-flash", "gemini-3.6-flash"];
  // Tenta TODAS as combinações chave×modelo; se falhar com 429/403/5xx, avança
  for (const key of KEYS) {
    for (const modelo of MODELOS) {
    try {
      const res = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/" + modelo + ":generateContent?key=" +
          encodeURIComponent(key),
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: AbortSignal.timeout(8000),
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.2,
              maxOutputTokens: 2000,
              responseMimeType: "application/json",
              responseSchema: SCHEMA,
            },
            safetySettings: [
              { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
              { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
            ],
          }),
        },
      );
      if (!res.ok) {
        lastErr = `Gemini ${res.status}`;
        if (res.status === 429) { erro429++; tentativasGemini++; }
        else if (res.status === 403 || res.status >= 500) { tentativasGemini++; }
        else { lastErr = await res.text().catch(() => lastErr); }
        // se todas as tentativas até aqui falharam em 429/5xx, aborta a cascata na hora
        if (tentativasGemini > 0 && tentativasGemini === erro429) { tudo429 = true; break; }
        continue;
      }
      const data = await res.json();
      const raw =
        data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      if (!raw) {
        lastErr = "resposta vazia do Gemini";
        continue;
      }
      let parsed: any;
      try {
        parsed = JSON.parse(raw);
      } catch {
        // bloco markdown ```json ... ```
        const m = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
        parsed = m ? JSON.parse(m[1]) : null;
      }
      if (!parsed || !parsed.intencao) {
        lastErr = "JSON incompleto";
        continue;
      }
      parsed.extra = parsed.extra || parsed.resumo || "";
      parsed.material = String(parsed.material || "").toLowerCase();
      return corsJson(parsed);
    } catch (e) {
      lastErr = e instanceof Error ? e.message : String(e);
      if (/timeout|abort|timed out/i.test(lastErr)) { erro429++; }
      tentativasGemini++;
      if (tentativasGemini > 0 && tentativasGemini === erro429) { tudo429 = true; break; }
      continue;
    }
    if (tudo429) break;
    }
  }

  // Fallback sem IA: palavras-chave mínimas — usa o perfil da loja quando disponível
  const m = mensagem.toLowerCase();
  let intencao = "desconhecido";
  let resposta = "";
  let encaminhar = false;
  const quem = lojaNome ? "da *" + lojaNome + "*" : "da serralheria";
  // segmento só entra se trouxer informação nova (não repetir "serralheria" genérica)
  const segBaixo = (segmento || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const oQue = (segBaixo && !/(serralher|galvanizad|inox)/.test(segBaixo)) ? segmento : "aço galvanizado e inox";
  if (/oi|olá|ola|bom dia|boa tarde|boa noite|opa|salve|alô|alo|e ai|e aí/.test(m)) {
    intencao = "saudacao";
    const trabalhaCom = (oQue !== "aço galvanizado e inox" && oQue.toLowerCase() !== lojaNome.toLowerCase()) ? " — a gente trabalha com *" + oQue + "*" : "";
    resposta = boasVindas || ("Olá! 👋 Aqui é " + quem + trabalhaCom + ". Me diz o que você precisa que eu te ajudo na hora! 😊");
  } else if (/tchau|obrigad|valeu|vlw|falou|até mais|ate mais/.test(m)) {
    intencao = "despedida";
    resposta = boasVindas ? "Obrigado! " + quem + " agradece e está à disposição. 👋😊" : "Obrigado por falar com a gente! 👋 Qualquer coisa, chama aqui. Estamos à disposição! 😊";
  } else if (/(pessoa|atendente|humano|responsável|responsavel|fechar|agendar|visita|medição|medicao)/.test(m)) {
    intencao = "chamar_humano";
    encaminhar = true;
    resposta = "Claro! Vou te encaminhar pro responsável agora. Um instante! 😊";
  } else if (/(orçamento|orcamento|valor|preço|preco|quanto|cotacao|cotação)/.test(m)) {
    intencao = "orcamento";
    resposta = "Claro! Me passa os detalhes: o que você precisa, a medida aproximada e o material? Assim te passo o valor na hora! 😊";
  }
  const causa = tudo429 ? "cota Gemini esgotada" : lastErr.slice(0, 120);
  return corsJson({
    erro: "IA sem resposta (" + causa + ")",
    intencao,
    confiavel: intencao !== "desconhecido",
    encaminhar_humano: encaminhar,
    resposta_natural: resposta,
    servico: "",
    material: "",
    medida: "",
    extra: "",
    loja_nome: lojaNome || null,
  });
});

function corsJson(obj: any): Response {
  return new Response(JSON.stringify(obj), {
    status: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
