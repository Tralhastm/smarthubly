# Bot Serralheria v5.2 — Guia de Instalação (Termux)

## O que é novo na v5.2

O bot agora conversa de forma natural e entende pedidos fora do catálogo fixo usando **IA (Gemini)**. Quando você manda algo como *"quero uma coifa"* ou *"preciso de um letreiro"*, a IA classifica o pedido automaticamente e conduz o orçamento. A IA roda agora como **Edge Function do Supabase dentro da sua infraestrutura SmartHubly** — mesma central dos workers do Super Admin — o que facilita a manutenção: trocar prompt ou chaves é só editar lá. Tudo **zero custo**.

### Cascata de resiliência (blindagem total)

O bot nunca fica sem IA. Cada mensagem passa por 4 camadas, em ordem:

1. **Catálogo local** — detecção instantânea de serviço/medida/material (grátis, sem internet na IA).
2. **SmartHubly (Supabase)** — `serralheria-intent` com 3 chaves Gemini em rotação × 2 modelos (2.5-flash principal, 3.6-flash reserva).
3. **Worker Cloudflare legado** (`yellow-butterfly-8b49`) — backup automático se a camada Supabase falhar.
4. **Gemini direto no bot** — último recurso com chave própria.

Se **tudo** falhar (ex.: cota do Google esgotada temporariamente), o bot responde por **palavras-chave** e continua atendendo normalmente. Nada quebra.

## Como atualizar no Termux

```bash
cd ~
# 1) faz backup da sua sessão atual (não perde o QR code!)
cp -r bot-termux/auth auth_backup

# 2) entra na pasta do bot
cd bot-termux

# 3) descompacta a nova versão
unzip -o botv5.2.zip

# 4) instala/atualiza dependências
npm install

# 5) (re)inicia o bot
./start.sh
```

Se preferir começar do zero:

```bash
cd ~
rm -rf bot-termux
mkdir bot-termux && cd bot-termux
unzip botv5.2.zip
npm install
./start.sh
```

O QR code será o mesmo (a pasta `auth` é preservada pelo backup no passo 1).

## Arquivos importantes

| Arquivo | O que faz |
|---|---|
| `bot.js` | O bot em si (v5.2) |
| `config.json` | Empresa, preços, horários, IA |
| `worker-ia.js` | Código da IA no Cloudflare (referência) |
| `teste_ia_v52.js` | Testa a IA do endpoint sem abrir o WhatsApp |
| `teste_blindagem.cjs` | Bateria massiva de teste (spam, injeção, gírias, casos bizarrros) |

## Teste rápido da IA

```bash
node teste_ia_v52.js
```

Deve aparecer "✅" para todos os casos. Se aparecer "❌ ERRO" em tudo, é a cota temporária do Google (libera sozinha em ~1 minuto) — é normal após vários testes seguidos. O bot continua respondendo normalmente nesse período.

## Observações

- O Wi-Fi corporativo funciona normalmente (o bot usa proxy configurado).
- IA principal (SmartHubly/Supabase): `https://qbcplbcdxoyqpmcehnvu.supabase.co/functions/v1/serralheria-intent`
- Se quiser alterar preços/serviços: edite `config.json` e reinicie o bot.
- Bateria de blindagem: 98 cenários testados (spam, emojis, injeção de código, XSS, URLs, gibberish, troca de assunto) — 100% de sucesso na camada local; camada IA protegida contra quota 429 pela cascata acima.
