// Teste das correções da v6.0.1 — extrai e testa apenas as funções puras
const fs = require("fs");
const src = fs.readFileSync(__dirname + "/bot.js", "utf8");

// Extrair blocos de funções puras por regex (detectarIntencao, normalizar, detectarMedida, detectarServico etc.)
// parser robusto: ignora chaves dentro de strings, comentários e literais de regex
function fnBlock(nome) {
  const i = src.indexOf("function " + nome);
  if (i === -1) return null;
  const start = i;
  let depth = 0, k = src.indexOf("{", i);
  let inStr = null, inRe = false, last = "";
  for (; k < src.length; k++) {
    const c = src[k];
    if (inStr) {
      if (c === "\\" ) { k++; continue; }
      if (c === inStr) inStr = null;
      continue;
    }
    if (inRe) {
      if (c === "\\") { k++; continue; }
      if (c === "/" && !["e", "E", "+", "-", "*", "("].includes(last) && !/[0-9a-z_$]/.test(last)) inRe = false;
      continue;
    }
    if (c === '"' || c === "'" || c === "`") { inStr = c; continue; }
    if (c === "/" && k + 1 < src.length && src[k+1] === "/") { while (k < src.length && src[k] !== "\n") k++; continue; }
    if (c === "{" ) { depth++; last = c; continue; }
    if (c === "}") {
      depth--;
      if (depth === 0) return src.slice(start, k + 1);
    }
    if (c === "(" && depth === 0 && k > 0) {
      // detectar início de regex: /= algo como ") /" ou "[ /" — heurística: após ) [ , = ! & | ? : ; { e operadores
      const prev = src.slice(Math.max(0, k-3), k).trim();
      if (/\)$|^[\[\],=;:&|!?{+\-]?$/.test(prev) || /return /.test(prev)) inRe = true;
    }
    last = c;
  }
  return null;
}

// Fatiamento por linhas conhecidas (fnBlock de chaves falha em regex literais)
const lines = src.split("\n");
function blockBetween(startLine, endLine) { return lines.slice(startLine - 1, endLine).join("\n"); }
// detectarIntencao: linhas 464-489 (antes do comentário "bot")
const funcs = [
  blockBetween(382, 387),  // normalizar
  blockBetween(389, 407),  // detectarServico
  blockBetween(409, 415),  // detectarMaterial
  blockBetween(417, 441),  // detectarMedida
  blockBetween(464, 489),  // detectarIntencao
];
// constantes necessárias
const iINT = src.indexOf("const INTENCOES = {");
const jINT = src.indexOf("};", iINT);
const INTENCOES_SRC = src.slice(iINT, jINT + 2);
const iF = src.indexOf("const INTENCOES_FORTES");
const jF = src.indexOf("];", iF);
const INTF_SRC = src.slice(iF, jF + 2);
const iAPE = src.indexOf("const APELIDOS_SERVICO");
const jAPE = (() => { let d=0, k=src.indexOf("{", iAPE); for(;k<src.length;k++){ if(src[k]==="{")d++;else if(src[k]==="}")if(--d===0) return src.slice(iAPE, k+1);} })();

const code = INTENCOES_SRC + "\n" + INTF_SRC + "\n" + jAPE + "\n" + funcs.filter(Boolean).join("\n");
console.log("funções extraídas:", funcs.filter(Boolean).length);
// funcs já está em ordem topológica (normalizar primeiro); eval único com newlines
const fullCode = INTENCOES_SRC + "\n" + INTF_SRC + "\n" + jAPE + "\n" + funcs.filter(Boolean).join("\n\n");
eval(fullCode);

let falhas = 0;
function test(nome, cond, detalhe) {
  if (cond) console.log("  ✅", nome);
  else { falhas++; console.log("  ❌", nome, detalhe !== undefined ? "(retornou: " + JSON.stringify(detalhe) + ")" : ""); }
}

console.log("--- 1) detectarIntencao ---");
test("excluir: 'pode excluir'", detectarIntencao("pode excluir") === "excluir", detectarIntencao("pode excluir"));
test("excluir: 'cancela'", detectarIntencao("cancela") === "excluir", detectarIntencao("cancela"));
test("excluir: 'pode apagar'", detectarIntencao("pode apagar") === "excluir", detectarIntencao("pode apagar"));
test("excluir: 'desfazer pedido'", detectarIntencao("desfazer") === "excluir", detectarIntencao("desfazer"));
test("oi continua saudação", detectarIntencao("oi") === "saudacao", detectarIntencao("oi"));
test("'Oi' não é excluir", detectarIntencao("Oi") !== "excluir");

console.log("\n--- 2) detectarMedida ---");
test("3 metros ok", detectarMedida("3 metros") === 3, detectarMedida("3 metros"));
test("2,5 m ok", detectarMedida("2,5 m") === 2.5, detectarMedida("2,5 m"));
test("3x2 área = 6", detectarMedida("3x2") === 6, detectarMedida("3x2"));
test("6 m2 = 6", detectarMedida("6 m2") === 6, detectarMedida("6 m2"));
test("número solto 3", detectarMedida("3") === 3, detectarMedida("3"));
test("texto sem número = null", detectarMedida("oi boa tarde") === null, detectarMedida("oi boa tarde"));
// o número gigante é capturado pelo detector, mas rejeitado pelo processador (limite 200)
test("31993095717 capturado (será rejeitado no processador)", detectarMedida("31993095717") === 31993095717);

console.log("\n--- 3) Verificações estáticas no código ---");
test("SESSAO_VIDA_MS definido", /const SESSAO_VIDA_MS = 30 \* 60 \* 1000;/.test(src));
test("expiração de sessão implementada", src.includes("orçamento órfão expirado"));
test("limite 200 na medida local", /medidaNova <= 200/.test(src));
test("limite IA 200 m² / 50 un", src.includes("LIMITE_M2 = 200") && src.includes("LIMITE_UN = 50"));
test("intenção excluir no fluxo local", src.includes('intencao === "excluir"'));
test("intenção excluir no fluxo IA", src.includes('intencaoIA === "excluir"'));
test("excluir no intenResolvida", src.includes('"agendar_visita", "excluir"').test ? src.includes('"excluir"') && /intenResolvida[^\n]*"excluir"/.test(src) : /intenResolvida[^\n]*"excluir"/.test(src));
test("medida IA rejeitada → confirmação", src.includes("medidaIARejeitada"));
test("saudação não herda sessão antiga", /atualizado && \(Date\.now\(\) - s\.atualizado\) > SESSAO_VIDA_MS/.test(src));

console.log("\nResultado:", falhas === 0 ? "TODOS OS TESTES PASSARAM" : falhas + " FALHARAM");
process.exit(falhas ? 1 : 0);
