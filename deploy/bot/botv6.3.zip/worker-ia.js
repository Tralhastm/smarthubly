// Worker de IA — SmartHubly Bot (serralheria/inox)
// Chave Gemini embutida (injetada no deploy)
// Rotação de chaves Gemini (free tier = 20 req/min por chave)
// v5.2: REMOVIDAS chaves inválidas (400) e referrer-restritas (403): A6RH, C26Q..., DR5y...
// Cascata de modelos: 2.5-flash primeiro (cota estável), 3.6-flash reserva
const GEMINI_KEYS = [
  "AIzaSyASOPA6l7frTwOUhZmZvTpx2n88JXkPptc",
  "AIzaSyBX6dHQKVJw96EeDBLYgazOxOUpyFxUAmg",
  "AQ.Ab8RN6JnCK8xYOY69s5j87RmGvekDfoNirItvutr3OfuTwCxFw",
];
const MODELOS = ["gemini-3.5-flash", "gemini-2.5-flash", "gemini-3.6-flash"];
let keyIdx = 0;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json; charset=utf-8" };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: { ...cors, "Access-Control-Allow-Methods": "POST,OPTIONS", "Access-Control-Allow-Headers": "Content-Type" } });
    }

    if (url.pathname === "/ping") {
      return new Response(JSON.stringify({ ok: true, ts: Date.now() }), { headers: cors });
    }

    if (url.pathname !== "/entender" || request.method !== "POST") {
      return new Response(JSON.stringify({ erro: "Use POST /entender" }), { status: 404, headers: cors });
    }

    let body;
    try { body = await request.json(); } catch { return new Response(JSON.stringify({ erro: "JSON inválido" }), { status: 400, headers: cors }); }

    const mensagem = String(body.mensagem || "").slice(0, 2000);
    const contexto = String(body.contexto || "");
    const chaveOverride = body.chave || null;

    const chavesUsaveis = chaveOverride ? [chaveOverride] : GEMINI_KEYS;
    const modelosUsaveis = MODELOS.slice();

    const model = body.modelo || "gemini-3.5-flash";

    const prompt = `Você é um classificador de intenções para uma serralheria de aço galvanizado e inox.
Retorne APENAS um objeto JSON puro. Nao use markdown nem crases, e nao adicione texto antes ou depois do JSON.

Mensagem do cliente: "${mensagem}"
${contexto ? "Contexto da conversa (serviço/medida/material já coletados): " + JSON.stringify(contexto) : ""}

Classifique e retorne:
- "servico": serviço de serralheria identificado (portão, grade, estrutura, escada, cobertura, varanda, mezanino, balcão, pérgola, letreiro, coifa, portão automático, corrimão, guarda-corpo, esquadria, manutenção, outro ou null)
- "material": galvanizado, inox ou null
- "medida": número ou dimensão mencionada (ex: "3", "2x4", "150cm") ou null
- "intencao": um entre "orcamento" | "pergunta_info" | "agendar_visita" | "chamar_humano" | "saudacao" | "despedida" | "resposta_sim" | "resposta_nao" | "negociacao" | "excluir" | "desconhecido"
- "extra": detalhes livres (tipo de serviço, complementos) ou null
- "resposta_natural": resposta natural e amigável de atendente (curta, 1-2 frases, tom brasileiro informal mas educado) OU null
- "confiavel": true se você tem certeza alta da classificação, false caso contrário
- "encaminhar_humano": true se a mensagem indica vontade de falar com pessoa real

Regras: "quero/preciso + serviço" = orcamento; perguntas sobre preço/horário/local/garantia = pergunta_info; "visita/orcamento presencial" = agendar_visita; frases de despedida ou recusa educada = despedida; "sim/não" curtos = resposta_sim/resposta_nao; reclamações de preço = negociacao; "exclui/excluir/apaga/cancela(não quero mais o orçamento)/desfazer/esquece isso" = excluir (mesmo que haja orçamento em andamento, o cliente quer CANCELAR tudo — responda confirmando o cancelamento).`;

    let gJson = {};
    let tentativa = 0;
    let erroUltimo = null;
    const MAX_TENT = chavesUsaveis.length * modelosUsaveis.length;
    // Tenta TODAS as combinações chave×modelo antes de desistir (quota pode esgotar 1-2)
    while (tentativa < MAX_TENT) {
      const chaveEscolhida = chaveOverride ? chaveOverride : chavesUsaveis[(keyIdx + tentativa) % GEMINI_KEYS.length];
      const modelEscolhido = modelosUsaveis[tentativa % modelosUsaveis.length];
      if (!chaveEscolhida || (!chaveEscolhida.startsWith("AIza") && !chaveEscolhida.startsWith("AQ."))) {
        tentativa += 1;
        continue;
      }
      const apiUrlFinal = `https://generativelanguage.googleapis.com/v1beta/models/${modelEscolhido}:generateContent?key=${encodeURIComponent(chaveEscolhida)}`;
      const gRes = await fetch(apiUrlFinal, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 2000, responseMimeType: "application/json", responseSchema: { type: "OBJECT", properties: { servico: { type: "STRING" }, material: { type: "STRING" }, medida: { type: "STRING" }, intencao: { type: "STRING" }, extra: { type: "STRING" }, resposta_natural: { type: "STRING" }, confiavel: { type: "BOOLEAN" }, encaminhar_humano: { type: "BOOLEAN" } }, required: ["intencao", "confiavel", "encaminhar_humano"] } }
        })
      });
      gJson = await gRes.json().catch(() => ({}));
      const txt = gJson?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      if (txt) { keyIdx = (keyIdx + tentativa + 1) % GEMINI_KEYS.length; break; }
      erroUltimo = gJson?.error || { code: gRes.status };
      tentativa += 1;
    }
    const texto = gJson?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const tentativas = tentativa;
    const errDetail = erroUltimo ? (erroUltimo.message || JSON.stringify(erroUltimo)).slice(0, 200) : null;

    let parsed = null;
    const fence = texto.match(/```(?:json)?\s*([\s\S]*?)```/);
    const src = fence ? fence[1] : (texto.match(/\{[\s\S]*\}/) || [null])[0];
    if (src) {
      try { parsed = JSON.parse(src); } catch {
        try { parsed = JSON.parse(src.replace(/[\n\r]+\s*/g, " ")); } catch { parsed = null; }
      }
    }

    return new Response(JSON.stringify(parsed ? { ...parsed, fonte: "ia" } : { erro: "IA sem resposta", tentativas, err: errDetail, raw: texto.slice(0, 200) }), { headers: cors });
  }
};
