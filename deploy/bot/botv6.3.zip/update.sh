#!/bin/bash
# Auto-atualização do bot — checa release.json na nuvem e atualiza sozinho
RELEASE="https://smarthubly.pages.dev/bot/release.json"
TMP=$(mktemp -d)
UA="-A 'Mozilla/5.0'"

echo "🔄 Verificando atualização do bot..."
INFO=$(curl -s -m 30 -H "Cache-Control: no-cache" "$RELEASE?cb=$(date +%s%N)")
if [ -z "$INFO" ]; then
  echo "⚠️  Servidor de atualização sem resposta — mantendo versão atual."
  rm -rf "$TMP"
  exit 0
fi

# versão atual local: tenta version do config, senão 0
LOCAL=$(node -e "const c=require('./config.json');process.stdout.write(String(c.versao||'5.2'))" 2>/dev/null || echo "5.2")
REMOTE=$(echo "$INFO" | node -e "let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',()=>{try{console.log(JSON.parse(d).versao)}catch(e){console.log('0')}})")
ZIP=$(echo "$INFO" | node -e "let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',()=>{try{console.log(JSON.parse(d).url)}catch(e){console.log('')}})")
NOTAS=$(echo "$INFO" | node -e "let d='';process.stdin.on('data',c=>d+=c);process.stdin.on('end',()=>{try{console.log(JSON.parse(d).notas||'')}catch(e){console.log('')}})")

echo "📦 Versão local: v$LOCAL | Versão na nuvem: v$REMOTE"

if [ -z "$REMOTE" ] || [ "$REMOTE" = "0" ]; then
  echo "⚠️  Não consegui ler a versão remota — mantendo versão atual."
  rm -rf "$TMP"
  exit 0
fi

if [ "$REMOTE" = "$LOCAL" ]; then
  echo "✅ Bot já está na versão mais recente (v$LOCAL)."
  rm -rf "$TMP"
  exit 0
fi

echo "📥 Baixando v$REMOTE: $ZIP"
curl -s -m 180 $ZIP -o "$TMP/bot.zip"
if [ ! -s "$TMP/bot.zip" ]; then
  echo "❌ Falha no download — mantendo versão atual."
  rm -rf "$TMP"
  exit 0
fi

# testa integridade do zip
unzip -t "$TMP/bot.zip" >/dev/null 2>&1 || { echo "❌ Zip corrompido no download — mantendo versão atual."; rm -rf "$TMP"; exit 0; }

# atualiza version do config.json local para a nova versão (preserva o config do usuário)
node -e "const fs=require('fs');const c=JSON.parse(fs.readFileSync('config.json','utf8'));c.versao='$REMOTE';fs.writeFileSync('config.json',JSON.stringify(c,null,2)+'\n')" 2>/dev/null

# extrai, preservando config.json, auth (sessão) e .manus-proxy se existirem
cp config.json "$TMP/" 2>/dev/null
cp .manus-proxy "$TMP/" 2>/dev/null
cp auth.json "$TMP/" 2>/dev/null
unzip -o -q "$TMP/bot.zip"
mv "$TMP/config.json" ./ 2>/dev/null
mv "$TMP/.manus-proxy" ./ 2>/dev/null
mv "$TMP/auth.json" ./ 2>/dev/null
chmod +x start.sh update.sh install.sh 2>/dev/null

echo "✅ Atualizado para v$REMOTE: $NOTAS"
echo "📦 Reiniciando o bot com a nova versão..."
rm -rf "$TMP"
