# Bot WhatsApp SmartHubly — v6.0 IA Conversadora 🗣️

## O que mudou na v6.0

O bot agora conversa **no mesmo nível dos assistentes das lojas (Sofia/Clara)**:

- **Conversa fluida em texto livre** — sem menu numerado. O cliente pode falar qualquer coisa e o bot entende e responde como um atendente.
- **Memória de conversa** — o bot lembra o que foi dito na sessão (serviço, medida, material, contexto) e a IA recebe o histórico completo a cada mensagem.
- **IA conversadora de verdade** — usa a Edge Function `serralheria-intent` (workers de IA + Gemini em cascata, custo zero) para responder perguntas sobre horário, materiais, garantia, localização etc., com o tom da loja.
- **Orçamento sem erro (zero NaN)** — o cálculo final continua sendo feito localmente no bot, com o trilho seguro serviço → medida → material. Nada de valores quebrados.
- **Entende contexto** — "quero um portão" → "de 3 metros" → "em inox" → orçamento pronto. E se a pessoa mudar de assunto no meio, o bot responde e volta pro orçamento depois.
- **Encaminhamento humano** — quando o cliente pede um atendente ou quer fechar, o bot chama a equipe.

## Como atualizar

O Termux atualiza sozinho: a cada mensagem (e a cada 30s em segundo plano) ele verifica o `release.json` e baixa a versão nova. É só manter o bot rodando (`./start.sh`) que ele se atualiza para a v6.0 automaticamente, sem perder `config.json`, `auth.json` nem o proxy.

## Atualização manual (se precisar)

```bash
cd ~/bot-termux
./update.sh
./start.sh
```

## Arquivos

| Arquivo | Função |
| --- | --- |
| `bot.js` | Motor do bot (conexão WhatsApp + IA + orçamento) |
| `config.json` | Perfil da loja (serviços, preços, horários, IA) |
| `update.sh` | Auto-atualização via `release.json` |
| `start.sh` | Inicia o bot |
| `install.sh` | Instala dependências |
| `worker-ia.js` | Worker IA legado (fallback) |
| `serralheria-intent/index.ts` | Código da Edge Function conversadora |

## Notas

- O `config.json` é preservado nas atualizações — suas mudanças ficam.
- Proxy: se seu Wi-Fi corporativo bloquear, o `GUIA_PROXY.md` explica como configurar.
