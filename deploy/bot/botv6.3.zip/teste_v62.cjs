// Teste de integração v6.2 — reproduz o cenário exato do print:
// sessão antiga com orçamento completo + medida absurda (31993095717) e "Exclui"
const fs = require("fs");
const src = fs.readFileSync("/home/ubuntu/botv6_work/bot.js", "utf8");
const lines = src.split("\n");

function block(startPat, endPat) {
  const a = lines.findIndex(l => l.includes(startPat));
  if (a < 0) throw new Error("start not found: " + startPat);
  let depth = 0, started = false, out = [];
  for (let i = a; i < lines.length; i++) {
    for (const ch of lines[i]) { if (ch === "{") depth++; if (ch === "}") depth--; }
    out.push(lines[i]);
    if (depth > 0) started = true;
    if (started && depth === 0) break;
  }
  return out.join("\n");
}

let code = "";
// Mock de CFG (PREÇOS = CFG.servicos) antes de qualquer função
code += `const CFG = { nome_empresa: "Ferro e aço ltda", servicos: { "Portão": { por_m2: true, preco_m2_min: 280, preco_m2_max: 480 }, "Corrimão / Guarda-corpo": { por_m2: false, preco_min: 150, preco_max: 300 }, "Grade": { por_m2: true, preco_m2_min: 200, preco_m2_max: 350 } }, materiais_info: "info", horarios: "horarios" };\n`;
code += `const getPrecoServico = s => CFG.servicos[s] || null;\n`;
// APELIDOS_SERVICO real (linhas 316 até antes de OUTROS/next const)
const apelidosEnd = lines.findIndex((l, i) => i >= 315 && l.trim().startsWith("};"));
code += "var APELIDOS_SERVICO = (" + lines.slice(315, apelidosEnd + 1).join("\n").replace(/^const APELIDOS_SERVICO\s*=\s*/, "").replace(/};\s*$/, "}") + ");\n";
code += `const INTENCOES_FORTES = ["horario", "local", "garantia", "material", "humano"];\n`;
// normalizar precisa vir primeiro (detectarIntencao depende dela)
code += block("function normalizar(", "}") + "\n";
code += block("function getPrecoExtra(", "}") + "\n";
code += block("const INTENCOES = {", "};") + "\n";
code += block("function detectarServico(", "}") + "\n";
code += block("function detectarMaterial(", "}") + "\n";
code += block("function detectarMedida(", "}") + "\n";
code += block("function detectarExtras(", "}") + "\n";
code += block("function detectarIntencao(", "}") + "\n";

let pass = 0, fail = 0;
function assert(cond, label) {
  if (cond) { pass++; console.log("  PASS", label); }
  else { fail++; console.log("  FAIL", label); }
}

eval(code);
console.log("--- Testes v6.2 ---");

// 1) "Exclui" (com i) deve retornar intenção excluir
assert(detectarIntencao("exclui") === "excluir", "detectarIntencao('exclui') = excluir");
assert(detectarIntencao("Pode excluir") === "excluir", "detectarIntencao('Pode excluir') = excluir");
assert(detectarIntencao("excluir") === "excluir", "detectarIntencao('excluir') = excluir");
assert(detectarIntencao("cancela cara") === "excluir", "detectarIntencao('cancela cara') = excluir");
assert(detectarIntencao("apaga tudo") === "excluir", "detectarIntencao('apaga tudo') = excluir");
assert(detectarIntencao("desisto") === "excluir", "detectarIntencao('desisto') = excluir");
assert(detectarIntencao("desfazer o orçamento") === "excluir", "detectarIntencao('desfazer o orçamento') = excluir");
assert(detectarIntencao("não quero mais") === "excluir", "detectarIntencao('não quero mais') = excluir");
assert(detectarIntencao("Exclui") === "excluir", "detectarIntencao('Exclui' maiúscula) = excluir");

// 2) Medida absurda local é rejeitada (>200)
assert(detectarMedida("31993095717 metros") === null, "medida 31993095717 rejeitada (local)");
assert(detectarMedida("3 metros") !== null && detectarMedida("3 metros") === 3, "medida 3 aceita");

// 3) Saudação não detecta serviço
assert(detectarServico("Oi") === null, "saudação 'Oi' sem serviço");
assert(detectarIntencao("Oi") === "saudacao", "intenção 'Oi' = saudacao");

console.log(`\nResultado: ${pass} passaram, ${fail} falharam`);
process.exit(fail ? 1 : 0);
