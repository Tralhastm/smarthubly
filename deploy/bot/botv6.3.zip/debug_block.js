const fs = require("fs");
const src = fs.readFileSync(__dirname + "/bot.js", "utf8");
function fnBlock(nome) {
  const i = src.indexOf("function " + nome);
  const start = i;
  let depth = 0, k = src.indexOf("{", i);
  let inStr = null, inRe = false, last = "";
  for (; k < src.length; k++) {
    const c = src[k];
    if (inStr) { if (c === "\\") { k++; continue; } if (c === inStr) inStr = null; continue; }
    if (inRe) { if (c === "\\") { k++; continue; } if (c === "/" && !["e","E","+","-","*","("].includes(last) && !/[0-9a-z_$]/.test(last)) inRe = false; continue; }
    if (c === '"' || c === "'" || c === "`") { inStr = c; continue; }
    if (c === "/" && k + 1 < src.length && src[k+1] === "/") { while (k < src.length && src[k] !== "\n") k++; continue; }
    if (c === "{") { depth++; last = c; continue; }
    if (c === "}") { depth--; if (depth === 0) return src.slice(start, k + 1); }
    last = c;
  }
  return null;
}
const nomes = ["normalizar", "detectarServico", "detectarMaterial", "detectarMedida", "detectarIntencao"];
for (const n of nomes) {
  const b = fnBlock(n);
  console.log(n, "->", b ? b.length : "NULL");
  if (b) console.log("  ... contem 'function normalizar'?", /function normalizar/.test(b));
}
