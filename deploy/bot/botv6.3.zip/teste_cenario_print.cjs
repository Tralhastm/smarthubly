// Cenário exato do print: sessão com orçamento absurdo (31993095717 m²) + "Pode excluir cara"
// Simula o núcleo do processar() da v6.1 usando as funções reais do bot.js
const fs = require("fs");
const src = fs.readFileSync(__dirname + "/bot.js", "utf8");
const lines = src.split("\n");
function blockBetween(a, b) { return lines.slice(a - 1, b).join("\n"); }

const funcs = [
  blockBetween(382, 387),
  blockBetween(389, 407),
  blockBetween(409, 415),
  blockBetween(417, 441),
  blockBetween(464, 489),
];

const iINT = src.indexOf("const INTENCOES = {");
const jINT = src.indexOf("};", iINT);
const INTENCOES_SRC = src.slice(iINT, jINT + 2);
const iF = src.indexOf("const INTENCOES_FORTES");
const INTF_SRC = src.slice(iF, src.indexOf("];", iF) + 2);
const iAPE = src.indexOf("const APELIDOS_SERVICO");
const jAPE = (() => { let d=0, k=src.indexOf("{", iAPE); for(;k<src.length;k++){ if(src[k]==="{")d++;else if(src[k]==="}")if(--d===0) return src.slice(iAPE, k+1);} })();
// APELIDOS_SERVICO depende de PREÇOS? verificar — pegar também o bloco PREÇOS
const iPRE = src.indexOf("const PREÇOS");
const PRE_SRC = iPRE === -1 ? null : src.slice(iPRE, src.indexOf("};", iPRE) + 2);

const code = PRE_SRC + "\n" + INTENCOES_SRC + "\n" + INTF_SRC + "\n" + jAPE + "\n" + funcs.join("\n\n");
eval(code);

let falhas = 0;
function test(nome, cond, detalhe) {
  if (cond) console.log("  ✅", nome);
  else { falhas++; console.log("  ❌", nome, detalhe !== undefined ? "(retornou: " + JSON.stringify(detalhe) + ")" : ""); }
}

console.log("--- Cenário do print ---");
// 1) "Pode excluir cara" — deve virar intenção excluir
const intencao = detectarIntencao("Pode excluir cara");
test("'Pode excluir cara' = excluir", intencao === "excluir", intencao);

// 2) Medida local de "31993095717" — detector captura, mas a sanidade do processador rejeita (>200)
const medida = detectarMedida("31993095717");
test("medida gigante capturada pelo detector (= 31993095717)", medida === 31993095717);
// condição de aceitação do processador:
const aceita = medida !== null && medida > 0 && isFinite(medida) && medida <= 200;
test("processador REJEITA a medida gigante", !aceita);

// 3) Medida normal aceita
const m3 = detectarMedida("3 metros");
test("processador ACEITA 3 metros", m3 !== null && m3 > 0 && isFinite(m3) && m3 <= 200);

// 4) Código contém o reset no ramo excluir
test("ramo local excluir zera sessão", src.includes('intencao === "excluir"') && /d\.servico = null/.test(src));
test("ramo IA excluir zera sessão", src.includes('intencaoIA === "excluir"'));

console.log("\nResultado:", falhas === 0 ? "TODOS OS TESTES PASSARAM" : falhas + " FALHARAM");
process.exit(falhas ? 1 : 0);
